/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        brand: {
          // Fundo escuro com nuance vinho/rosa
          bg: '#05010A',
          bgSoft: '#120018',
          // Primárias em rosa
          primary: '#ec4899',       // rosa vibrante
          primaryDeep: '#db2777',   // rosa mais profundo
          primarySoft: '#f472b6',   // rosa suave
          // Acentos e textos
          accent: '#f9a8d4',
          accentSoft: '#fbcfe8',
          border: 'rgba(248, 113, 169, 0.4)',
        },
      },
    },
  },
  plugins: [
    function({ addUtilities }) {
      const newUtilities = {
        '.no-select': {
          '-webkit-user-select': 'none !important',
          '-moz-user-select': 'none !important',
          '-ms-user-select': 'none !important',
          'user-select': 'none !important',
          '-webkit-touch-callout': 'none !important',
          '-webkit-tap-highlight-color': 'transparent !important',
        },
        '.allow-select': {
          '-webkit-user-select': 'text !important',
          '-moz-user-select': 'text !important',
          '-ms-user-select': 'text !important',
          'user-select': 'text !important',
          '-webkit-touch-callout': 'default !important',
        },
        '.no-drag': {
          '-webkit-user-drag': 'none !important',
          '-khtml-user-drag': 'none !important',
          '-moz-user-drag': 'none !important',
          '-o-user-drag': 'none !important',
          'user-drag': 'none !important',
        },
      }
      addUtilities(newUtilities)
    }
  ],
};
