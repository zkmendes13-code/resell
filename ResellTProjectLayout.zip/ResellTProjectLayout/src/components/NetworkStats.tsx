
import { memo } from 'react';
import { Download, Upload } from 'lucide-react';
import { useNetworkStatsGlobal } from '../hooks/useGlobalPolling';

const NetworkStats = memo(function NetworkStats() {
  const {
    downloadSpeed,
    uploadSpeed,
    formattedTotalDownloaded,
    formattedTotalUploaded
  } = useNetworkStatsGlobal();

  return (
    <section className="w-full max-w-md md:max-w-xl lg:max-w-xs lg:w-full mx-auto p-4 md:p-6 lg:p-3 network-stats-mobile-landscape rounded-2xl lg:rounded-xl bg-gradient-to-br from-[#100016]/90 via-[#1a021e]/90 to-[#2A001C]/90 border border-pink-500/40 shadow-lg shadow-black/60 backdrop-blur-xl flex flex-col gap-3 md:gap-6 lg:gap-3 lg:mt-4 lg:sticky lg:top-4">
      {/* Título para landscape */}
      <div className="hidden lg:block text-center mb-2">
        <h3 className="text-pink-100 text-sm font-semibold uppercase tracking-wide">Estatísticas</h3>
      </div>
      
      <div className="flex justify-between items-center gap-4 md:gap-8 lg:gap-3 lg:flex-col lg:items-stretch">
        <div className="flex flex-col items-center flex-1 lg:flex-col lg:items-center lg:bg-pink-500/10 lg:p-3 lg:rounded-lg lg:border lg:border-pink-500/30">
          <div className="flex items-center gap-1.5 text-pink-100 lg:mb-2">
            <Download className="w-5 h-5 md:w-6 md:h-6 lg:w-4 lg:h-4" />
            <span className="text-xs md:text-sm lg:text-xs font-semibold uppercase tracking-wide">Download</span>
          </div>
          <div className="flex flex-col lg:flex-col lg:items-center lg:gap-1">
            <span className="text-pink-100 font-mono text-lg md:text-2xl lg:text-lg font-bold drop-shadow text-center">
              {downloadSpeed}
            </span>
            <span className="text-xs md:text-sm lg:text-xs text-pink-100/70 mt-1 lg:mt-0 text-center">Total: {formattedTotalDownloaded}</span>
          </div>
        </div>
        
        <div className="w-px h-12 md:h-16 lg:w-full lg:h-px bg-gradient-to-b lg:bg-gradient-to-r from-pink-200/40 to-transparent mx-2 lg:mx-0 lg:my-2" />
        
        <div className="flex flex-col items-center flex-1 lg:flex-col lg:items-center lg:bg-pink-500/10 lg:p-3 lg:rounded-lg lg:border lg:border-pink-500/30">
          <div className="flex items-center gap-1.5 text-pink-100 lg:mb-2">
            <Upload className="w-5 h-5 md:w-6 md:h-6 lg:w-4 lg:h-4" />
            <span className="text-xs md:text-sm lg:text-xs font-semibold uppercase tracking-wide">Upload</span>
          </div>
          <div className="flex flex-col lg:flex-col lg:items-center lg:gap-1">
            <span className="text-pink-100 font-mono text-lg md:text-2xl lg:text-lg font-bold drop-shadow text-center">
              {uploadSpeed}
            </span>
            <span className="text-xs md:text-sm lg:text-xs text-pink-100/70 mt-1 lg:mt-0 text-center">Total: {formattedTotalUploaded}</span>
          </div>
        </div>
      </div>
    </section>
  );
});

export { NetworkStats };
export default NetworkStats;