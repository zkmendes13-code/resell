import { memo } from 'react';

interface AnimatedLogoProps {
  logo: string;
  alt?: string;
}

const logoStyles = `
  @keyframes logoSimple {
    0% {
      transform: scale(0.97) rotate(-6deg);
      filter: drop-shadow(0 2px 8px rgba(236,72,153,0.18));
    }
    50% {
      transform: scale(1.06) rotate(7deg);
      filter: drop-shadow(0 0 24px rgba(251,113,133,0.7)) brightness(1.13);
    }
    100% {
      transform: scale(0.97) rotate(-6deg);
      filter: drop-shadow(0 2px 8px rgba(236,72,153,0.18));
    }
  }
  .animate-logo {
    animation: logoSimple 3.2s cubic-bezier(0.45,0,0.2,1) infinite;
    will-change: opacity, transform, filter, box-shadow;
    border-radius: 50%;
    background: transparent;
    box-shadow:
      0 0 8px 2px rgba(248, 113, 169, 0.55),
      0 0 26px 8px rgba(219, 39, 119, 0.55),
      0 4px 18px 0 rgba(15, 23, 42, 0.65);
    transition: filter 0.3s, box-shadow 0.3s, transform 0.3s;
  }
  .animate-logo:hover {
    filter: drop-shadow(0 0 0 rgba(255,255,255,0.5)) drop-shadow(0 0 18px rgba(251,113,133,0.9)) brightness(1.18) blur(0.4px);
    opacity: 1;
    transform: scale(1.12) rotate(8deg);
    box-shadow: 0 0 38px 14px rgba(236,72,153,0.45);
    transition: filter 0.3s, transform 0.3s, opacity 0.3s, box-shadow 0.3s;
  }
  @media (prefers-reduced-motion: reduce) {
    .animate-logo {
      animation: none;
    }
  }
`;

export const AnimatedLogo = memo(function AnimatedLogo({ logo, alt = "RESELL T PROJECT" }: AnimatedLogoProps) {
  return (
    <>
      <style>{logoStyles}</style>
      <div className="relative rounded-full overflow-visible group">
        <img
          className="w-28 h-28 md:w-40 md:h-40 lg:w-28 lg:h-28 object-contain animate-logo rounded-full group-hover:animate-logoPulse"
          id="app-logo"
          src={logo}
          alt={alt}
          style={{
            filter:
              'drop-shadow(0 4px 18px rgba(236,72,153,0.45)) drop-shadow(0 1px 4px rgba(0,0,0,0.32))',
          }}
        />
        {/* Fade shadow overlays */}
        <div
          className="pointer-events-none absolute inset-0 rounded-full animate-shadowPulse"
          style={{
            boxShadow:
              '0 0 18px 7px rgba(236,72,153,0.32), 0 0 0 2px rgba(248, 250, 252, 0.06) inset',
            borderRadius: '50%',
          }}
        />
        {/* Extra animated glow ring */}
        <div className="absolute inset-0 flex items-center justify-center pointer-events-none rounded-full">
          <span className="animate-glowRing block w-full h-full rounded-full border-2 border-pink-400/50" />
        </div>
        {/* Pulse ring */}
        <span className="absolute inset-0 flex items-center justify-center pointer-events-none">
          <span className="pulse-ring" />
        </span>
      </div>
    </>
  );
});