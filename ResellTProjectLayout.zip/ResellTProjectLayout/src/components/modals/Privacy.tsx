import { Shield, Check, ShieldCheck } from 'lucide-react';
import { Modal } from './Modal';
import { usePrivacyAcceptance } from '../../hooks/usePrivacyAcceptance';

interface PrivacyProps {
  onClose: () => void;
  onAccept?: () => void;
}

export function Privacy({ onClose, onAccept }: PrivacyProps) {
  const { accepted, acceptPrivacy } = usePrivacyAcceptance();

  const handleAccept = () => {
    acceptPrivacy();
    if (onAccept) onAccept();
  };

  return (
    <Modal onClose={onClose} allowClose={accepted} title="Política de Privacidade" icon={Shield}>
      <div className="relative flex-1 p-4">
        <header className="flex items-center gap-3 mb-6">
          <div className="w-12 h-12 rounded-full bg-fuchsia-950/80 flex items-center justify-center">
            <Shield className="w-6 h-6 text-pink-200" />
          </div>
        </header>
        {accepted && (
          <div className="flex justify-center mb-6">
            <span className="flex items-center gap-2 text-sm text-green-300">
              <ShieldCheck className="w-4 h-4" /> Política Aceita
            </span>
          </div>
        )}
        <div className="p-4 rounded-lg bg-black/25 border border-pink-500/35 backdrop-blur-md">
          <div className="prose prose-invert max-w-none">
            <p className="text-pink-50/90 mb-4">
              A sua privacidade é importante para nós. Esta Política de Privacidade explica como coletamos, usamos e protegemos suas informações ao utilizar o aplicativo Resell T Project.
            </p>

            <section className="mb-6">
              <h2 className="text-lg font-medium text-pink-100 mb-4">1. Informações Coletadas</h2>
              <p className="text-pink-50/90 mb-4">
                O Resell Resell Resell T Project coleta apenas o Device ID do seu dispositivo. Esse identificador é armazenado junto ao seu usuário em nossa base de dados para a finalidade exclusiva de limitar o número de conexões simultâneas.
              </p>
            </section>

            <section className="mb-6">
              <h2 className="text-lg font-medium text-pink-100 mb-4">2. Uso dos Dados</h2>
              <ul className="list-disc list-inside text-pink-50/90 space-y-2">
                <li>Controle de conexões simultâneas por usuário</li>
                <li>Garantia do funcionamento adequado do serviço</li>
              </ul>
              <p className="text-pink-50/90 mt-4">
                Não utilizamos os dados para rastreamento, publicidade ou qualquer outra finalidade além da citada acima.
              </p>
            </section>

            <section className="mb-6">
              <h2 className="text-lg font-medium text-pink-100 mb-4">3. Armazenamento e Segurança</h2>
              <ul className="list-disc list-inside text-pink-50/90 space-y-2">
                <li>O Device ID é armazenado em nossa base de dados sem criptografia</li>
                <li>Os Device IDs são automaticamente apagados diariamente</li>
                <li>Nenhuma outra informação do usuário é armazenada</li>
              </ul>
            </section>

            <section className="mb-6">
              <h2 className="text-lg font-medium text-pink-100 mb-4">4. Compartilhamento de Dados</h2>
              <p className="text-pink-50/90 mb-4">
                O Resell T Project não compartilha suas informações com terceiros, parceiros ou serviços externos.
              </p>
            </section>

            <section className="mb-6">
              <h2 className="text-lg font-medium text-pink-100 mb-4">5. Direitos do Usuário</h2>
              <p className="text-pink-50/90 mb-4">
                Como usuário, você tem o direito de:
              </p>
              <ul className="list-disc list-inside text-pink-50/90 space-y-2">
                <li>Solicitar informações sobre os dados armazenados</li>
                <li>Solicitar a exclusão dos seus dados</li>
              </ul>
              <p className="text-pink-50/90">
              Para entrar em contato, envie um e-mail para <a href="mailto:talkera@sshtproject.com" className="underline text-pink-200">talkera@sshtproject.com</a>
                </p>
            </section>

            <section className="mb-6">
              <h2 className="text-lg font-medium text-pink-100 mb-4">6. Base Legal e Responsabilidade</h2>
              <p className="text-pink-50/90 mb-4">
                O Resell T Project não pertence a uma empresa registrada legalmente. O tratamento de dados é feito de forma automatizada, sem intervenção humana.
              </p>
            </section>

            <section className="mb-6">
              <h2 className="text-lg font-medium text-pink-100 mb-4">7. Alterações na Política de Privacidade</h2>
              <p className="text-pink-50/90 mb-4">
                Podemos atualizar esta política de tempos em tempos. Quaisquer alterações serão publicadas nesta página, e o uso continuado do serviço implica na aceitação da política revisada.
              </p>
                <p className="text-pink-50/90">
                Caso tenha dúvidas, entre em contato pelo e-mail <a href="mailto:talkera@sshtproject.com" className="underline text-pink-200">talkera@sshtproject.com</a>
                </p>
            </section>

            <footer className="mt-8 pt-4 border-t border-pink-500/30">
              <p className="text-sm text-pink-100/60 text-center">
                Última atualização: 23/03/2025 - RESELL T PROJECT
              </p>
            </footer>
          </div>
        </div>

        <div className="mt-4 sticky bottom-0 left-0 right-0 p-4 backdrop-blur-lg border-t border-pink-500/30">
          {!accepted && (
            <button
              onClick={handleAccept}
              className="w-full h-12 rounded-lg font-medium flex items-center justify-center gap-2 bg-pink-500 text-pink-50 hover:bg-pink-600"
            >
              <Check className="w-5 h-5" />
              Aceitar Política de Privacidade
            </button>
          )}
        </div>
      </div>
    </Modal>
  );
}