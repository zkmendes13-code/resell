import React, { useEffect, useState } from 'react';
import {
  Settings, Download,
  Wifi, Battery, Network, Book,
  RefreshCw, DollarSign, Share2, CalendarClock, BriefcaseBusiness, Search, Zap, Phone
} from 'lucide-react';
import {
  checkForUpdates,
  openApnSettings,
  openNetworkSettings,
  checkBatteryOptimization,
  getStatusbarHeight,
  getNavbarHeight,
  openExternalUrl,
} from '../../utils/appFunctions';
import { ModalType } from '../../App';
import { ServersModal } from '../modals/ServersModal';
import { Support } from '../modals/Support';
import { useAutoConnect } from '../../hooks/useAutoConnect';
import { AutoConnectModal } from '../AutoConnectModal';

interface SidebarProps {
  isOpen: boolean;
  onClose: () => void;
  onNavigate: (modal: ModalType) => void;
}

interface MenuCategory {
  title: string;
  items: {
    icon: React.ReactNode;
    label: string;
    onClick: () => void;
    highlight?: boolean;
  }[];
}

export function Sidebar({ isOpen, onClose, onNavigate }: SidebarProps) {
  const [menuStyle, setMenuStyle] = useState({});
  const [showServersModal, setShowServersModal] = useState(false);
  
  // Hook para AutoConnect
  const autoConnect = useAutoConnect();
  const [showSupportModal, setShowSupportModal] = useState(false);

  useEffect(() => {
    const statusBarHeight = getStatusbarHeight();
    const navBarHeight = getNavbarHeight();

    setMenuStyle({
      padding: `${statusBarHeight + 10}px 0px ${navBarHeight + 10}px 0px`
    });
  }, []);

  const menuCategories: MenuCategory[] = [
    {
      title: "Ações Rápidas",
      items: [
        {
          icon: <RefreshCw className="w-5 h-5" />,
          label: "Renovar pelo Painel",
          onClick: () => openExternalUrl('https://painel.reselltproject.shop/renovar.php'),
          highlight: true,
        },
      ]
    },
    {
      title: "Ferramentas",
      items: [
        { icon: <Zap className="w-5 h-5" />, label: "Teste Automático", onClick: () => autoConnect.openModal(), highlight: true },
        { icon: <Download className="w-5 h-5" />, label: "Speed Test", onClick: () => onNavigate('speedtest') },
        { icon: <Share2 className="w-5 h-5" />, label: "Hotspot", onClick: () => onNavigate('hotspot') },
        { icon: <Search className="w-5 h-5" />, label: "Buscador de IP", onClick: () => onNavigate('ipfinder') },
      ]
    },
    {
      title: "Configurações",
      items: [
        { icon: <Battery className="w-5 h-5" />, label: "Bateria", onClick: checkBatteryOptimization },
        { icon: <Wifi className="w-5 h-5" />, label: "Ajustes de APN", onClick: openApnSettings },
        { icon: <Network className="w-5 h-5" />, label: "Ajustes de Rede", onClick: openNetworkSettings },
        { icon: <RefreshCw className="w-5 h-5" />, label: "Verificar Atualizações", onClick: checkForUpdates }
      ]
    }
  ];

  return (
    <>
      <div className={`fixed inset-0 bg-black/50 backdrop-blur-sm z-40 transition-opacity duration-300
        ${isOpen ? 'opacity-100' : 'opacity-0 pointer-events-none'}`} onClick={onClose} />

      <aside className={`
        fixed inset-y-0 left-0 w-[300px] max-w-[85vw]
        sidebar-mobile-landscape backdrop-blur-2xl
        bg-[radial-gradient(circle_at_top_left,rgba(236,72,153,0.22),transparent_55%),radial-gradient(circle_at_bottom_right,rgba(244,114,182,0.18),transparent_55%),rgba(10,2,18,0.96)]
        transform transition-transform duration-300 ease-[cubic-bezier(0.4,0,0.2,1)]
        border-r border-pink-500/40 shadow-2xl shadow-pink-900/40 z-50
        ${isOpen ? 'translate-x-0' : '-translate-x-full'}
      `} style={menuStyle}>
        <div className="flex flex-col h-full">
          {/* Header */}
          <div className="flex items-center justify-between px-4 pb-4 border-b border-pink-500/30">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-full bg-gradient-to-br from-pink-500 to-rose-500 flex items-center justify-center shadow-lg shadow-pink-500/40">
                <Settings className="w-6 h-6 text-white" />
              </div>
              <div>
                <span className="text-white font-medium">RESELL T PROJECT</span>
                <span className="text-pink-200/80 text-sm block">Configurações</span>
              </div>
            </div>
            <button
              onClick={onClose}
              className="w-8 h-8 flex items-center justify-center rounded-full hover:bg-pink-500/10 transition-colors"
            >
              <svg className="w-5 h-5 text-pink-200/80" viewBox="0 0 24 24">
                <path
                  fill="currentColor"
                  d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"
                />
              </svg>
            </button>
          </div>

          {/* Menu Items com novas categorias */}
          <div className="flex-1 overflow-y-auto py-4">
            {menuCategories.map((category, idx) => (
              <div key={category.title} className={`px-3 ${idx > 0 ? 'mt-6' : ''}`}>
                <h3 className="text-xs font-semibold text-pink-200/50 uppercase tracking-wider mb-2 px-3">
                  {category.title}
                </h3>
                <div className="space-y-1">
                  {category.items.map((item) => (
                    <MenuItem
                      key={item.label}
                      icon={item.icon}
                      label={item.label}
                      onClick={item.onClick}
                      className={item.highlight ? 'bg-pink-500/10 hover:bg-pink-500/20' : ''}
                      iconClassName={item.highlight ? 'text-pink-200' : ''}
                    />
                  ))}
                </div>
              </div>
            ))}
          </div>

          {/* Footer com botões */}
          <div className="px-4 py-4 border-t border-pink-500/30 bg-black/10 backdrop-blur-xl space-y-2">
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => onNavigate('terms')}
                className="px-4 py-2 rounded-lg bg-pink-500/10 hover:bg-pink-500/20 
                  transition-all duration-200 text-pink-100 text-sm font-medium"
              >
                Termos de Uso
              </button>
              <button
                onClick={() => onNavigate('privacy')}
                className="px-4 py-2 rounded-lg bg-pink-500/10 hover:bg-pink-500/20 
                  transition-all duration-200 text-pink-100 text-sm font-medium"
              >
                Privacidade
              </button>
            </div>
            <button
              onClick={() => onNavigate('cleandata')}
              className="w-full px-4 py-2 rounded-lg bg-red-500/10 hover:bg-red-500/20 
                transition-all duration-200 text-red-400 text-sm font-medium"
            >
              Limpar Dados
            </button>
          </div>
        </div>
      </aside>

      {/* Modals */}
      {showServersModal && (
        <ServersModal onClose={() => setShowServersModal(false)} />
      )}

      <AutoConnectModal
        open={autoConnect.open}
        onClose={autoConnect.closeModal}
        currentConfigName={autoConnect.currentName}
        totalConfigs={autoConnect.total}
        testedConfigs={autoConnect.tested}
        successConfigName={autoConnect.success}
        running={autoConnect.running}
        onStart={autoConnect.startAutoConnect}
        onCancel={autoConnect.cancelTest}
        error={autoConnect.error}
        logs={autoConnect.logs}
        currentTestDuration={autoConnect.currentTestDuration}
        autoConnectConfig={autoConnect.autoConnectConfig}
        setAutoConnectConfig={autoConnect.setAutoConnectConfig}
        showSettings={autoConnect.showSettings}
        setShowSettings={autoConnect.setShowSettings}
      />
      {showSupportModal && (
        <Support onClose={() => setShowSupportModal(false)} />
      )}
    </>
  );
}

interface MenuItemProps {
  icon: React.ReactNode;
  label: string;
  onClick: () => void;
  className?: string;
  iconClassName?: string;
}

function MenuItem({ icon, label, onClick, className = '', iconClassName = '' }: MenuItemProps) {
  return (
    <button
      onClick={onClick}
      className={`
        w-full flex items-center gap-3 px-4 h-12 rounded-lg text-pink-100 
        hover:bg-pink-500/10 transition-all duration-200
        active:scale-[0.98] hover:shadow-lg hover:shadow-pink-500/10
        ${className}
      `}
    >
      <div className={`text-pink-400 ${iconClassName}`}>
        {icon}
      </div>
      <span className="text-sm font-medium">{label}</span>
    </button>
  );
}